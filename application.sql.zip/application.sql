-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2024 at 07:04 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `application`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `balance` int(11) NOT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `ComName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `balance`, `pic`, `country`, `ComName`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Syed Imran Ertaza', 1924329315, 'Noapara, Abhaynagar, Jessore', 30954, 'admin_1705377620_cf6fb1a15c4b0f6d6c77.jpg', '', 'amarbangla', 1, '1', 1, '2018-11-21 18:05:40', 1, '2024-01-16 10:01:53', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `applicant`
--

CREATE TABLE `applicant` (
  `applicant_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(155) NOT NULL,
  `nid` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date_of_barth` date NOT NULL,
  `mobile` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `present_address` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `problem` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `transition_id` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `number` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applicant`
--

INSERT INTO `applicant` (`applicant_id`, `name`, `gender`, `nid`, `date_of_barth`, `mobile`, `present_address`, `problem`, `transition_id`, `number`, `status`, `createdDtm`) VALUES
(4, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(5, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(6, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(7, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(8, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(9, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(10, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(11, 'আব্দুর রহিম', 'Male', '412414124', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'আমরা অসহায় মানুষের ঋণ পরিশোধ করি এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব।', '232323123', '213123123', '1', '2024-02-08 18:40:43'),
(12, 'আব্দুর রহিম', 'Male', '০১৮৫১৬৭০৪০৩', '2024-02-08', '০১৮৫১৬৭০৪০৩', 'অভয়নগর যশোর', 'এটি আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে, সমাজের ন্যায় এবং সমতা বজায় রাখার জন্য আমাদের দায়িত্ব। ', '০১৮৫১৬৭০৪০৩', '০১৮৫১৬৭০৪০৩', '1', '2024-02-08 19:27:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `applicant`
--
ALTER TABLE `applicant`
  ADD PRIMARY KEY (`applicant_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `applicant`
--
ALTER TABLE `applicant`
  MODIFY `applicant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
